interact = {}

interact.configured = true --Change this to true when you've configured the mod!

--Which screens to show.
interact.screen1 = true --The welcome a first question screen.
interact.screen2 = true --The visit or interact screen.
interact.screen4 = true --The quiz screen.

--The first screen--
--The text at the top.
interact.s1_header = "Salut, bienvenue sur Graphene!"
--Lines one and two. Make sure each line is less than 70 characters, or they will run off the screen.
interact.s1_l2 = "Est-ce que tu aimes grief ou pas?"
interact.s1_l3 = ""
--The buttons. Each can have 15 characters, max.
interact.s1_b1 = "Non."
interact.s1_b2 = "Oui, j'adore!"

--The message to send kicked griefers.
interact.msg_grief = "Si tu aimes faire ça, vas sur le mode solo car tu ne détruis que tes propres choses!"

--Ban or kick griefers? Default is kick, set to true for ban.
interact.grief_ban = false

--The second screen--
--Lines one and two. Make sure each line is less than 70 characters, or they will run off the screen.
interact.s2_l1 = "Alors, tu veux pouvoir interagir"
interact.s2_l2 = "Sur Graphene?"
--The buttons. These ones can have a maximum of 26 characters.
interact.s2_b1 = "Oui, je veux bien!"
interact.s2_b2 = "Je veux juste visiter ce serveur."

--The message the player is sent if s/he is just visiting.
interact.visit_msg = "D'accord amuse-toi bien à le visiter, si tu veux revoir cette page fais /rules dans le chat!"

--The third screen--
--The header for the rules box, this can have 60 characters, max.
interact.s3_header = "Ici il y a les règles:"

--The buttons. Each can have 15 characters, max.
interact.s3_b1 = "J'accepte"
interact.s3_b2 = "Je n'accepte pas"

--The message to send players who disagree when they are kicked for disagring with the rules.
interact.disagree_msg = "Alors au revoir, tu dois accepter les règles pour rester ici."

--Kick, ban or ignore players who disagree with the rules.
--Options are "kick" "ban" "nothing"
interact.disagree_action = "kick"

--The fouth screen--
--Should there be a back to rules button?
interact.s4_to_rules_button = true
--The back to rules button. 13 characters, max.
interact.s4_to_rules = "Retour aux règles"

--The header for screen 4. 60 characters max, although this is a bit of a squash. I recomend 55 as a max.
interact.s4_header = "C'est l'heure d'un petit quiz!"

--Since the questions are intrinsically connected with the rules, they are to be found in rules.lua
--The trues are limited to 24 characters. The falses can have 36 characters.
interact.s4_question1_true = "Oui."
interact.s4_question1_false = "Non."
interact.s4_question2_true = "Oui."
interact.s4_question2_false = "Non."
interact.s4_question3_true = "Oui."
interact.s4_question3_false = "Non."
interact.s4_question4_true = "Oui."
interact.s4_question4_false = "Non."

interact.s4_submit = "Soumettre!"

--What to do on a wrong quiz.
--Options are "kick" "ban" "reshow" "rules" and "nothing"
interact.on_wrong_quiz = "nothing"
--The message to send the player if reshow is the on_wrong_quiz option.
interact.quiz_try_again_msg = "Trouves une autre voie."
--The message sent to the player if rules is the on_wrong_quiz option.
interact.quiz_rules_msg = "Les règles sont à revoir:"
--The kick reason if kick is the on_wrong_quiz option.
interact.wrong_quiz_kick_msg = "Prends plus d'attention la prochaine fois!"
--The message sent to the player if nothing is the on_wrong_quiz option.
interact.quiz_fail_msg = "C'est faux."

--The messages send to the player after interact is granted.
interact.interact_msg1 = "Merci d'avoir accepté(e) les règles, tu as maintenant la possibilité d'interagir."
interact.interact_msg2 = "Amuse-toi bien!"

--The priv required to use the /rules command. If fast is a default priv, I recomend replacing shout with that.
interact.priv = {shout = true}
