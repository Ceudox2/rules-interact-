--The actual rules.
interact.rules = [[
Règles:

1. N'endommages pas le serveur avec de la lave ou de l'eau...
2. Tu n'as pas le droit de te connecter avec un pseudo inapproprié.
3. Pas de jurons où d'insultes envers les autres joueurs.
4. Le spam ce fait seulement sur le salon de spam du serveur discord.
5. Pas de demande à devenir membre du staff.
6. Les demandes de grade ce font sur notre serveur Discord.
7. Le PvP est autorisé, seulement si la personne est d'accord.
]]

--The questions on the rules, if the quiz is used.
--The checkboxes for the first 4 questions are in config.lua
interact.s4_question1 = "La demande admin est autorisé?"
interact.s4_question2 = "Les insultes sont autorisées?"
interact.s4_question3 = "Dois-tu être gentil(le) avec tout le monde?"
interact.s4_question4 = "Le spam est autorisé sur le serveur Minetest?"
interact.s4_multi_question = "Choisis la bonne réponse"

--The answers to the multiple choice questions. Only one of these should be true.
interact.s4_multi1 = "Pas de grief!"
interact.s4_multi2 = "La dégradation est autorisé."
interact.s4_multi3 = "Sois impoli."

--Which answer is needed for the quiz questions. interact.quiz1-4 takes true or false.
--True is left, false is right.
--Please, please spell true and false right!!! If you spell it wrong it won't work!
--interact.quiz can be 1, 2 or 3.
--1 is the top one by the question, 2 is the bottom left one, 3 is the bottom right one.
--Make sure these agree with your answers!
interact.quiz1 = false
interact.quiz2 = false
interact.quiz3 = true
interact.quiz4 = false
interact.quiz_multi = 1
